//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by FinalProject.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_FINALPROJECT_DIALOG         102
#define IDR_MAINFRAME                   128
#define IDR_MENU1                       131
#define IDI_ICON1                       132
#define IDI_ICON2                       133
#define IDI_ICON3                       134
#define IDI_ICON4                       135
#define IDI_ICON5                       136
#define IDC_BUTTON2                     1008
#define IDC_BUTTON3                     1010
#define IDC_BUTTON1                     1011
#define IDC_BUTTON4                     1016
#define IDC_BUTTON5                     1017
#define IDC_BUTTON6                     1018
#define IDC_BUTTON7                     1019
#define IDC_CHECK1                      1030
#define IDC_SLIDER1                     1033
#define IDC_MFCCOLORBUTTON1             1035
#define IDC_MFCCOLORBUTTON2             1036
#define IDC_BUTTON8                     1037
#define IDC_EDIT1                       1038
#define MY_TITLE_LBL                    1039
#define IDC_COMBO1                      1040
#define ID_SHAPES_ELLIPSE               32771
#define ID_SHAPES_RECTANGLE             32772
#define ID_SHAPES_LINE                  32773
#define ID_SHAPES_RECTANGLECIRC         32774
#define ID_RECTANGLE_RECTANGLECIRC      32775
#define ID_RECTANGLE_RECTANGLE          32776
#define ID_RECTANGLE_RECTANGLE32777     32777
#define ID_RECTANGLE_RECTANGLE32778     32778
#define ID_SHAPES_TRIANGLE              32779

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32780
#define _APS_NEXT_CONTROL_VALUE         1042
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
